package com.dynamiccore;

public final class AsciiBanner {

    private AsciiBanner() {}

    public static final String DESIGN_CREDIT = """
§8╔══════════════════════════════════════════════════════════════════════╗
     §8| §fDᴇsɪɢɴᴇᴅ Bʏ §bLʏиX §8| §3Sɪʟᴇɴᴛ §8| §aFᴀsᴛ §8| §cDᴇᴀᴅʟʏ §8|
§8╚══════════════════════════════════════════════════════════════════════╝
""";
}